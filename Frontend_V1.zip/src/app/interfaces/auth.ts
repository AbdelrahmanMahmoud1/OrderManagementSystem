export interface User {
    lastName: any;
    firstName: any;
    id: string;
    fullName: string;
    email: string;
    password: string;
    role: string;
}
